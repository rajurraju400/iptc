#!/bin/bash
BUCKET_HOST=$(oc get -n open-cluster-management-observability configmap obc-observability -o jsonpath='{.data.BUCKET_HOST}')
BUCKET_NAME=$(oc get -n open-cluster-management-observability configmap obc-observability -o jsonpath='{.data.BUCKET_NAME}')
BUCKET_PORT=$(oc get -n open-cluster-management-observability configmap obc-observability -o jsonpath='{.data.BUCKET_PORT}')
ACCESS_KEY_ID=$(oc get -n open-cluster-management-observability secret obc-observability -o jsonpath='{.data.AWS_ACCESS_KEY_ID}' | base64 -d)
SECRET_ACCESS_KEY=$(oc get -n open-cluster-management-observability secret obc-observability -o jsonpath='{.data.AWS_SECRET_ACCESS_KEY}' | base64 -d)

cat <<EOF | oc apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: thanos-object-storage
  namespace: open-cluster-management-observability
type: Opaque
stringData:
  thanos.yaml: |
    type: s3
    config:
      bucket: $BUCKET_NAME
      endpoint: $BUCKET_HOST:$BUCKET_PORT
      insecure: false
      access_key: $ACCESS_KEY_ID
      secret_key: $SECRET_ACCESS_KEY
      http_config:
        insecure_skip_verify: true
EOF